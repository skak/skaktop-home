<?php
die ( "<h1>Merruk Technology, SARL. doulCi Server.</h1><a href=\"http://www.merruk.com\">Thank you and hope you enjoyed the service. Go Back to the website.</a>" );
?>