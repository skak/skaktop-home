<?php
/*
 * doulCi Project Remote Shutdown File.
 */

// Remote Close The Server
file_put_contents ( "Remote_Controle.data", "am done!" );

?>